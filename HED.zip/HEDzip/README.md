Original implementation:
https://github.com/sniklaus/pytorch-hed

- Installation
  - conda env create -f env.yml
  - conda activate pytorch-hed

```bash
$ tree

.

├── env.yml

├── HED

│   ├── prediction.sh

│   └── useful.pdf

├── LICENSE

├── MorphologicalOperations.pdf

├── pdf

│   └── create_pdf.py

├── README.md

└── run.py


```
run.py is the main execution file. No changes needed.

HED/predict.sh is the script I wrote to automatically process all image files.

pdf/create_pdf.py is the script to automatically generate pdf files based folder names. 
