%% Local Laplacian image filter
% last edited 2/8/22 by Alex Bordas

clc;clear;

tic

display_last = 'YES';         % 'YES' to display last image
GAUSSIAN_BLUR_VALUE = 1;    % adjusts level of blur (~ 0.5 to 8)
SIGMA = 0.4;        %changeable parameter for amplitude of edges, default = 0.4
ALPHA = 0.3;        %changeable parameter for smoothing, default = 0.5
BETA = 1.3;         %changeable parameter for dynamic range, default = 1

location = 'C:\Users\abordas\Desktop\images\images\*.jpg';         % location of images
folder = 'C:\Users\abordas\Desktop\GrainSegmentation\HED\';        % end location
ds = imageDatastore(location);

for i = 1:length(ds.Files)
    img = readimage(ds,i);
    %fprintf('Processing %s',ds)
    %img_gauss= imgaussfilt(img,GAUSSIAN_BLUR_VALUE);     
    %img_llf = locallapfilt(img_gauss,SIGMA,ALPHA);         
    img_llf = locallapfilt(img,SIGMA,ALPHA,BETA);
    %img_gauss = imgaussfilt(img_llf,GAUSSIAN_BLUR_VALUE);
    %img_llf = localcontrast(img,ALPHA,SIGMA);
    [filepath, name] = fileparts(ds.Files(i));
    outfile = fullfile(folder,'name.jpg');
    imwrite(img_llf, sprintf('%s_edited(gauss_and_llf).jpg',name));
end

if display_last == 'YES'
    ax1 = subplot(2,2,1);
    imshow(img)
    ax2 = subplot(2,2,2);
    imshow(img_llf)
    %ax3 = subplot(2,2,3);
    %imshow(img_gauss)
    fprintf('Number of images processed:%d \n',length(ds.Files))
end

toc