

#ls .tif, then .jpg
ls *.jpg |  while read line
do
  #folder need to contain .jpg and .tif
  folder="${line%.jpg}"
  pred="${folder}_prediction.png"
  if [ ! -d $folder ]; 
  then
    echo "Processing $line"
    mkdir $folder
    mv $line $folder
    python ../run.py --model bsds500 --in ./$folder/$line --out ./$folder/$pred
  else
    echo "Processing $line"
    python ../run.py --model bsds500 --in ./$folder/$line --out ./$folder/$pred
  fi
done
